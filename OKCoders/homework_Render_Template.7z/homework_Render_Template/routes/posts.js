var express = require('express');
var postsData = require('../models/postsData');
var router = express.Router();

var posts = postsData.all();


/* Renders GET:/POSTS listing. */
router.get('/', function(req, res) {
  res.render("index", {
    title: "Home",
    body: "Here's a table with items pulled from postsData.js.",
    posts: posts
  });
});

/* Renders GET:/POSTS/NEW listing. */
router.get('/new', function(req, res) {
  res.render("new", {
    title: "New Post",
    body: "Enter your post here...."
  });
});


/* Renders GET:POSTS/NEW/:ID listings */
router.get('/:id', function(req, res) {
  var postID = req.params.id;
  res.render("show", {
  	title: "View Post ",
  	body: "Displaying post# ",
  	pid: postID,
  	postTitle: posts[postID - 1].title,
  	postAuthor: posts[postID - 1].author,
  	postComment: posts[postID - 1].body
  });
});


/* Renders GET:POSTS/NEW/:ID/Edit listings */
router.get('/:id/edit', function(req, res) {
  var postID = req.params.id;
  res.render("edit", {
  	title: "Edit Post ",
  	body: "Edit your post here...",
  	pid: postID,
  	postTitle: posts[postID - 1].title,
  	postAuthor: posts[postID - 1].author,
  	postComment: posts[postID - 1].body
  });
});

module.exports = router;
